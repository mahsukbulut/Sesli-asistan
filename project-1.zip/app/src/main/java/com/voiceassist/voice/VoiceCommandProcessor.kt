package com.voiceassist.voice

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.speech.tts.TextToSpeech
import com.voiceassist.data.AppDatabase
import com.voiceassist.service.ReminderManager
import com.voiceassist.data.Reminder
import java.util.*
import java.util.concurrent.TimeUnit

class VoiceCommandProcessor(private val context: Context) {

    data class CommandResult(val success: Boolean, val message: String, val speakText: String? = null)

    private val tts: TextToSpeech by lazy {
        TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("tr", "TR")
            }
        }
    }

    fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    fun process(rawText: String): CommandResult {
        val text = rawText.lowercase(Locale("tr", "TR")).trim()
        return when {
            listOf("hatırlat", "hatırlatma kur", "reminder").any { text.contains(it) } -> processReminder(text)
            listOf("whatsapp mesaj oku", "mesajlarımı oku", "whatsapp oku", "mesajları oku").any { text.contains(it) } -> processWhatsAppRead()
            listOf("whatsapp mesaj gönder", "mesaj gönder", "mesaj yaz").any { text.contains(it) } -> processWhatsAppWrite(text, rawText)
            listOf("alarm kur", "alarm ayarla", "uyandır").any { text.contains(it) } -> processAlarm(text)
            listOf("ara", "çağır", "telefon aç").any { text.contains(it) } && !text.contains("whatsapp") -> processCall(text)
            listOf("aç", "başlat").any { text.contains(it) } -> processOpenApp(text)
            else -> CommandResult(false, "❓ Komut anlaşılamadı: \"$rawText\"")
        }
    }

    // ── HATIRLATMA ───────────────────────────────────────────────────────────
    // "10 dakika sonra toplantı hatırlat", "yarın saat 9'da doktor randevusu hatırlat"
    private fun processReminder(text: String): CommandResult {
        val triggerTime = extractReminderTime(text) ?: return CommandResult(
            false, "❌ Hatırlatma zamanı anlaşılamadı. Örnek: \"10 dakika sonra toplantı hatırlat\""
        )
        val reminderText = extractReminderText(text)

        val db = AppDatabase.getInstance(context)
        val id = db.reminderDao().insert(Reminder(text = reminderText, triggerTime = triggerTime))
        ReminderManager.schedule(context, id, reminderText, triggerTime)

        val cal = Calendar.getInstance().apply { timeInMillis = triggerTime }
        val timeStr = String.format("%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE))
        return CommandResult(true, "⏰ Hatırlatma kuruldu: \"$reminderText\" — $timeStr",
            speakText = "$reminderText için $timeStr saatinde hatırlatma kuruldu.")
    }

    private fun extractReminderTime(text: String): Long? {
        val now = Calendar.getInstance()

        // "X dakika sonra"
        Regex("""(\d+)\s*dakika sonra""").find(text)?.let {
            return now.timeInMillis + TimeUnit.MINUTES.toMillis(it.groupValues[1].toLong())
        }
        // "X saat sonra"
        Regex("""(\d+)\s*saat sonra""").find(text)?.let {
            return now.timeInMillis + TimeUnit.HOURS.toMillis(it.groupValues[1].toLong())
        }
        // "yarın saat HH:MM" veya "yarın HH"
        val tomorrowMatch = Regex("""yarın.*?(\d{1,2})(?::(\d{2}))?""").find(text)
        if (tomorrowMatch != null) {
            val h = tomorrowMatch.groupValues[1].toInt()
            val m = tomorrowMatch.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
            val cal = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, 1)
                set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0)
            }
            return cal.timeInMillis
        }
        // "bugün/saat HH:MM"
        val timeMatch = Regex("""(?:saat\s+)?(\d{1,2})[:.](\d{2})""").find(text)
            ?: Regex("""saat\s+(\d{1,2})(?!\d)""").find(text)
        if (timeMatch != null) {
            val h = timeMatch.groupValues[1].toInt()
            val m = timeMatch.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0)
            }
            if (cal.timeInMillis < now.timeInMillis) cal.add(Calendar.DAY_OF_YEAR, 1)
            return cal.timeInMillis
        }
        return null
    }

    private fun extractReminderText(text: String): String {
        return text
            .replace(Regex("""\d+\s*dakika sonra"""), "")
            .replace(Regex("""\d+\s*saat sonra"""), "")
            .replace(Regex("""yarın.*?\d{1,2}(?::\d{2})?(?:'de|'da)?"""), "")
            .replace(Regex("""(?:saat\s+)?\d{1,2}[:.]?\d{0,2}(?:'de|'da)?"""), "")
            .replace("hatırlat", "").replace("hatırlatma kur", "")
            .trim().ifBlank { "Hatırlatma" }
    }

    // ── WHATSAPP MESAJ OKUMA ────────────────────────────────────────────────
    private fun processWhatsAppRead(): CommandResult {
        val db = AppDatabase.getInstance(context)
        val unread = db.whatsAppDao().getUnread()

        if (unread.isEmpty()) {
            return CommandResult(true, "📭 Okunmamış WhatsApp mesajı yok.",
                speakText = "Okunmamış WhatsApp mesajınız bulunmuyor.")
        }

        val summary = unread.take(5).joinToString("\n") { "💬 ${it.sender}: ${it.text}" }
        val speakSummary = unread.take(5).joinToString(". ") { "${it.sender} yazdı: ${it.text}" }

        db.whatsAppDao().markAllRead()

        return CommandResult(true, "📱 ${unread.size} yeni mesaj:\n$summary", speakText = speakSummary)
    }

    // ── WHATSAPP MESAJ YAZMA ────────────────────────────────────────────────
    // "Ahmet'e mesaj gönder: yarın görüşelim"
    private fun processWhatsAppWrite(text: String, raw: String): CommandResult {
        val nameMatch = Regex("""([a-züğşıöçA-ZÜĞŞİÖÇ][a-züğşıöçA-ZÜĞŞİÖÇ]+)['’]?[ye]?\s+(?:mesaj|whatsapp)""").find(text)
        val name = nameMatch?.groupValues?.get(1)?.trim()
        val messageMatch = Regex("""(?:gönder|yaz)\s*:\s*(.+)""", RegexOption.IGNORE_CASE).find(raw)
        val message = messageMatch?.groupValues?.get(1)?.trim() ?: ""

        if (name == null) {
            return CommandResult(false, "❌ Kime mesaj göndereceğim anlaşılamadı.")
        }

        val number = findContactNumber(name)
        if (number == null) {
            return CommandResult(false, "❌ \"$name\" rehberde bulunamadı.")
        }

        val clean = number.replace(Regex("[^\\d]"), "")
        val waNum = if (clean.startsWith("0")) "90${clean.substring(1)}" else clean
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("https://wa.me/$waNum?text=${Uri.encode(message)}")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)

        return CommandResult(true, "💬 WhatsApp açıldı → $name: \"$message\"\n(Göndermek için Gönder'e dokunun)",
            speakText = "$name kişisine mesaj hazırlandı. Göndermek için WhatsApp'taki gönder tuşuna basın.")
    }

    private fun findContactNumber(name: String): String? {
        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )
        cursor?.use {
            while (it.moveToNext()) {
                val cn = it.getString(0) ?: continue
                if (cn.contains(name, true) || name.contains(cn, true)) return it.getString(1)
            }
        }
        return null
    }

    // ── ALARM ────────────────────────────────────────────────────────────────
    private fun processAlarm(text: String): CommandResult {
        val time = extractTime(text) ?: return CommandResult(false, "❌ Saat anlaşılamadı.")
        val (hour, minute) = time
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
        val timeStr = String.format("%02d:%02d", hour, minute)
        return CommandResult(true, "⏰ Alarm kuruldu: $timeStr", speakText = "$timeStr için alarm kuruldu.")
    }

    private fun extractTime(text: String): Pair<Int, Int>? {
        val patterns = listOf(
            Regex("""(\d{1,2})[:.](\d{2})"""),
            Regex("""sabah\s+(\d{1,2})(?::(\d{2}))?"""),
            Regex("""akşam\s+(\d{1,2})(?::(\d{2}))?"""),
            Regex("""saat\s+(\d{1,2})(?!\d)"""),
        )
        for (p in patterns) {
            val m = p.find(text) ?: continue
            var h = m.groupValues[1].toIntOrNull() ?: continue
            val min = m.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
            if (text.contains("akşam") && h < 12) h += 12
            if (h in 0..23 && min in 0..59) return Pair(h, min)
        }
        return null
    }

    // ── ARAMA ────────────────────────────────────────────────────────────────
    private fun processCall(text: String): CommandResult {
        val nameMatch = Regex("""([a-züğşıöçA-ZÜĞŞİÖÇ][a-züğşıöçA-ZÜĞŞİÖÇ\s]+?)['’]?[yi]?\s+ara""").find(text)
        val name = nameMatch?.groupValues?.get(1)?.trim()
        val number = name?.let { findContactNumber(it) }
            ?: Regex("""(\d[\d\s]{8,14}\d)""").find(text)?.value?.replace(" ", "")

        if (number == null) return CommandResult(false, "❌ \"$name\" rehberde bulunamadı.")

        val intent = Intent(Intent.ACTION_CALL).apply {
            data = Uri.parse("tel:${number.replace(" ", "")}")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
        return CommandResult(true, "📞 Aranıyor: ${name ?: number}", speakText = "${name ?: "Numara"} aranıyor.")
    }

    // ── UYGULAMA AÇ ──────────────────────────────────────────────────────────
    private val appMap = mapOf(
        "whatsapp" to "com.whatsapp", "instagram" to "com.instagram.android",
        "youtube" to "com.google.android.youtube", "spotify" to "com.spotify.music",
        "kamera" to "android.media.action.IMAGE_CAPTURE", "takvim" to "com.google.android.calendar",
    )

    private fun processOpenApp(text: String): CommandResult {
        val matched = appMap.entries.find { text.contains(it.key) } ?: return CommandResult(false, "❓ Uygulama bulunamadı.")
        return try {
            val pm = context.packageManager
            val intent = pm.getLaunchIntentForPackage(matched.value)
                ?: Intent(matched.value).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
            CommandResult(true, "📱 Açıldı: ${matched.key}", speakText = "${matched.key} açılıyor.")
        } catch (e: Exception) {
            CommandResult(false, "❌ ${matched.key} yüklü değil.")
        }
    }
}
