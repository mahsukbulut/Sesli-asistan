package com.voiceassist

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class VoiceAssistantApp : Application() {
    companion object {
        const val CH_VOICE = "voice_channel"
        const val CH_REMINDER = "reminder_channel"
        const val CH_WHATSAPP = "whatsapp_channel"
    }

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH_VOICE, "Sesli Asistan Servisi", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_REMINDER, "Hatırlatmalar", NotificationManager.IMPORTANCE_HIGH))
            nm.createNotificationChannel(NotificationChannel(CH_WHATSAPP, "WhatsApp Mesajları", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }
}
