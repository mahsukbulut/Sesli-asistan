package com.voiceassist.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.voiceassist.databinding.ActivityLockBinding
import com.voiceassist.security.SecurityManager

class LockActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLockBinding
    private lateinit var security: SecurityManager
    private var pin = StringBuilder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLockBinding.inflate(layoutInflater)
        setContentView(binding.root)
        security = SecurityManager(this)

        if (!security.isSetupDone()) {
            startActivity(Intent(this, SetupActivity::class.java)); finish(); return
        }
        setupUI()
        if (security.isBiometricAvailable()) tryBiometric()
    }

    private fun setupUI() {
        updateDots()
        val buttons = listOf(
            binding.btn0 to "0", binding.btn1 to "1", binding.btn2 to "2", binding.btn3 to "3",
            binding.btn4 to "4", binding.btn5 to "5", binding.btn6 to "6", binding.btn7 to "7",
            binding.btn8 to "8", binding.btn9 to "9"
        )
        buttons.forEach { (btn, d) -> btn.setOnClickListener {
            if (pin.length < 6) { pin.append(d); updateDots(); if (pin.length >= 4) checkPin() }
        }}
        binding.btnDelete.setOnClickListener { if (pin.isNotEmpty()) { pin.deleteCharAt(pin.length-1); updateDots() } }
        binding.btnBio.setOnClickListener { tryBiometric() }
    }

    private fun tryBiometric() {
        if (!security.isBiometricAvailable()) return
        security.showBiometric(this, onSuccess = { goMain() }, onFail = {})
    }

    private fun checkPin() {
        if (security.verifyPin(pin.toString())) goMain()
        else { Toast.makeText(this, "Yanlış PIN", Toast.LENGTH_SHORT).show(); pin.clear(); updateDots() }
    }

    private fun updateDots() {
        binding.tvDots.text = "●".repeat(pin.length) + "○".repeat(maxOf(0, 4 - pin.length))
    }

    private fun goMain() {
        startActivity(Intent(this, MainActivity::class.java)); finish()
    }

    override fun onBackPressed() { moveTaskToBack(true) }
}
