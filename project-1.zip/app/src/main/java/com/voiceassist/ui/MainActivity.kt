package com.voiceassist.ui

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.voiceassist.R
import com.voiceassist.databinding.ActivityMainBinding
import com.voiceassist.service.VoiceListenerService
import com.voiceassist.data.AppDatabase
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var isServiceRunning = false
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val voiceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == VoiceListenerService.ACTION_RESULT) {
                val text = intent.getStringExtra(VoiceListenerService.EXTRA_TEXT) ?: ""
                val result = intent.getStringExtra(VoiceListenerService.EXTRA_RESULT) ?: ""
                binding.tvLastCommand.text = "\"$text\""
                binding.tvLastResult.text = result
                binding.cardLastCommand.visibility = View.VISIBLE
                refreshWhatsAppCount()
            }
        }
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
        if (perms.values.all { it }) startVoiceService()
        else Toast.makeText(this, "İzinler olmadan çalışamaz", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        registerReceiver()
        updateStatus()
        refreshWhatsAppCount()
        checkNotificationAccess()
    }

    private fun setupUI() {
        binding.btnToggle.setOnClickListener {
            if (isServiceRunning) stopVoiceService() else requestPermsAndStart()
        }
        binding.btnNotifAccess.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        binding.cardWhatsapp.setOnClickListener {
            Toast.makeText(this, "Sesli komut: \"WhatsApp mesajlarımı oku\"", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestPermsAndStart() {
        val required = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) required.add(Manifest.permission.POST_NOTIFICATIONS)
        val toRequest = required.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (toRequest.isEmpty()) startVoiceService() else permLauncher.launch(toRequest.toTypedArray())
    }

    private fun startVoiceService() {
        startForegroundService(Intent(this, VoiceListenerService::class.java))
        isServiceRunning = true; updateStatus()
    }

    private fun stopVoiceService() {
        startService(Intent(this, VoiceListenerService::class.java).apply { action = VoiceListenerService.ACTION_STOP })
        isServiceRunning = false; updateStatus()
    }

    private fun updateStatus() {
        isServiceRunning = VoiceListenerService.isRunning
        binding.btnToggle.text = if (isServiceRunning) "🛑 Servisi Durdur" else "🎙 Servisi Başlat"
        binding.tvStatus.text = if (isServiceRunning) "● AKTİF — dinleniyor" else "● DURDU"
    }

    private fun checkNotificationAccess() {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        binding.cardNotifWarning.visibility = if (enabled) View.GONE else View.VISIBLE
    }

    private fun refreshWhatsAppCount() {
        scope.launch {
            val count = withContext(Dispatchers.IO) {
                AppDatabase.getInstance(this@MainActivity).whatsAppDao().getUnread().size
            }
            binding.tvWhatsappCount.text = if (count > 0) "$count okunmamış mesaj" else "Yeni mesaj yok"
        }
    }

    private fun registerReceiver() {
        val filter = IntentFilter(VoiceListenerService.ACTION_RESULT)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            registerReceiver(voiceReceiver, filter, RECEIVER_NOT_EXPORTED)
        else registerReceiver(voiceReceiver, filter)
    }

    override fun onResume() { super.onResume(); updateStatus(); checkNotificationAccess(); refreshWhatsAppCount() }
    override fun onDestroy() { super.onDestroy(); unregisterReceiver(voiceReceiver); scope.cancel() }
}
