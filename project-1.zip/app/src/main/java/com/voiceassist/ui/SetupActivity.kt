package com.voiceassist.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.voiceassist.databinding.ActivitySetupBinding
import com.voiceassist.security.SecurityManager

class SetupActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySetupBinding
    private lateinit var security: SecurityManager
    private var first = ""
    private var pin = StringBuilder()
    private var confirming = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySetupBinding.inflate(layoutInflater)
        setContentView(binding.root)
        security = SecurityManager(this)
        setupUI()
    }

    private fun setupUI() {
        binding.tvTitle.text = "PIN Belirle"
        val buttons = listOf(
            binding.btn0 to "0", binding.btn1 to "1", binding.btn2 to "2", binding.btn3 to "3",
            binding.btn4 to "4", binding.btn5 to "5", binding.btn6 to "6", binding.btn7 to "7",
            binding.btn8 to "8", binding.btn9 to "9"
        )
        buttons.forEach { (btn, d) -> btn.setOnClickListener {
            if (pin.length < 6) { pin.append(d); updateDots() }
        }}
        binding.btnDelete.setOnClickListener { if (pin.isNotEmpty()) { pin.deleteCharAt(pin.length-1); updateDots() } }
        binding.btnConfirm.setOnClickListener {
            if (pin.length < 4) { Toast.makeText(this, "En az 4 hane", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            if (!confirming) {
                first = pin.toString(); pin.clear(); confirming = true
                binding.tvTitle.text = "PIN'i Onayla"; updateDots()
            } else {
                if (pin.toString() == first) {
                    security.setPin(pin.toString())
                    startActivity(Intent(this, MainActivity::class.java)); finish()
                } else {
                    Toast.makeText(this, "Uyuşmadı, tekrar deneyin", Toast.LENGTH_SHORT).show()
                    pin.clear(); confirming = false; first = ""
                    binding.tvTitle.text = "PIN Belirle"; updateDots()
                }
            }
        }
    }

    private fun updateDots() {
        binding.tvDots.text = "●".repeat(pin.length) + "○".repeat(maxOf(0, 4 - pin.length))
    }
}
