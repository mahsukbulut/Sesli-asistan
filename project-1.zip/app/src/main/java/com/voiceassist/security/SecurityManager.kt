package com.voiceassist.security

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest

class SecurityManager(private val context: Context) {
    companion object {
        private const val PREFS = "va_secure"
        private const val KEY_PIN = "pin_hash"
        private const val KEY_SETUP = "setup_done"
    }

    private val masterKey by lazy { MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build() }
    private val prefs by lazy {
        EncryptedSharedPreferences.create(context, PREFS, masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    }

    fun isSetupDone() = prefs.getBoolean(KEY_SETUP, false)

    fun setPin(pin: String) {
        prefs.edit().putString(KEY_PIN, hash(pin)).putBoolean(KEY_SETUP, true).apply()
    }

    fun verifyPin(pin: String): Boolean = prefs.getString(KEY_PIN, null) == hash(pin)

    fun isBiometricAvailable(): Boolean {
        val bm = BiometricManager.from(context)
        return bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
    }

    fun showBiometric(activity: FragmentActivity, onSuccess: () -> Unit, onFail: () -> Unit) {
        val executor = ContextCompat.getMainExecutor(context)
        val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) = onSuccess()
            override fun onAuthenticationFailed() = onFail()
        })
        prompt.authenticate(BiometricPrompt.PromptInfo.Builder()
            .setTitle("Kimlik Doğrula").setNegativeButtonText("PIN Kullan").build())
    }

    private fun hash(pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest("va_salt_$pin".toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
