package com.voiceassist.data

import android.content.Context
import androidx.room.*

// ── WHATSAPP MESAJLARI ─────────────────────────────────────────────────────
@Entity(tableName = "whatsapp_messages")
data class WhatsAppMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

@Dao
interface WhatsAppDao {
    @Query("SELECT * FROM whatsapp_messages ORDER BY timestamp DESC LIMIT 50")
    fun getRecent(): List<WhatsAppMessage>

    @Query("SELECT * FROM whatsapp_messages WHERE isRead = 0 ORDER BY timestamp DESC")
    fun getUnread(): List<WhatsAppMessage>

    @Insert
    fun insert(msg: WhatsAppMessage)

    @Query("UPDATE whatsapp_messages SET isRead = 1")
    fun markAllRead()

    @Query("DELETE FROM whatsapp_messages WHERE timestamp < :before")
    fun deleteOlderThan(before: Long)
}

// ── HATIRLATMALAR ───────────────────────────────────────────────────────────
@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val triggerTime: Long,
    val isDone: Boolean = false
)

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders WHERE isDone = 0 ORDER BY triggerTime ASC")
    fun getActive(): List<Reminder>

    @Insert
    fun insert(r: Reminder): Long

    @Query("UPDATE reminders SET isDone = 1 WHERE id = :id")
    fun markDone(id: Long)

    @Query("SELECT * FROM reminders WHERE id = :id LIMIT 1")
    fun getById(id: Long): Reminder?
}

// ── KOMUT GEÇMİŞİ ────────────────────────────────────────────────────────────
@Entity(tableName = "command_history")
data class CommandEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val command: String,
    val result: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface CommandDao {
    @Query("SELECT * FROM command_history ORDER BY timestamp DESC LIMIT 50")
    fun getAll(): List<CommandEntity>

    @Insert
    fun insert(c: CommandEntity)
}

// ── VERİTABANI ───────────────────────────────────────────────────────────────
@Database(
    entities = [WhatsAppMessage::class, Reminder::class, CommandEntity::class],
    version = 1, exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun whatsAppDao(): WhatsAppDao
    abstract fun reminderDao(): ReminderDao
    abstract fun commandDao(): CommandDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "va_db")
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
    }
}
