package com.voiceassist.service

import android.app.*
import android.content.Intent
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import com.voiceassist.R
import com.voiceassist.VoiceAssistantApp
import com.voiceassist.data.AppDatabase
import com.voiceassist.data.CommandEntity
import com.voiceassist.ui.MainActivity
import com.voiceassist.voice.VoiceCommandProcessor
import kotlinx.coroutines.*

class VoiceListenerService : Service() {
    companion object {
        const val NOTIF_ID = 1001
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_RESULT = "com.voiceassist.VOICE_RESULT"
        const val EXTRA_TEXT = "text"
        const val EXTRA_RESULT = "result"
        var isRunning = false
    }

    private var recognizer: SpeechRecognizer? = null
    private lateinit var processor: VoiceCommandProcessor
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var isListening = false

    override fun onCreate() {
        super.onCreate()
        processor = VoiceCommandProcessor(this)
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        startForeground(NOTIF_ID, buildNotif("🎙 Dinleniyor..."))
        initRecognizer()
        startListening()
        return START_STICKY
    }

    private fun initRecognizer() {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
    }

    private fun startListening() {
        if (isListening) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        recognizer?.startListening(intent)
        isListening = true
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: android.os.Bundle?) { updateNotif("🎙 Konuşabilirsiniz...") }
        override fun onResults(results: android.os.Bundle?) {
            isListening = false
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!text.isNullOrBlank()) {
                val result = processor.process(text)
                result.speakText?.let { processor.speak(it) }

                scope.launch(Dispatchers.IO) {
                    AppDatabase.getInstance(this@VoiceListenerService).commandDao()
                        .insert(CommandEntity(command = text, result = result.message))
                }

                sendBroadcast(Intent(ACTION_RESULT).apply {
                    putExtra(EXTRA_TEXT, text); putExtra(EXTRA_RESULT, result.message)
                    `package` = packageName
                })
                updateNotif("✅ ${result.message.take(60)}")
            }
            scope.launch { delay(1800); initRecognizer(); startListening() }
        }
        override fun onPartialResults(p: android.os.Bundle?) {
            p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { updateNotif("💬 $it") }
        }
        override fun onError(error: Int) {
            isListening = false
            scope.launch { delay(2000); initRecognizer(); startListening() }
        }
        override fun onBeginningOfSpeech() {}
        override fun onEndOfSpeech() { isListening = false }
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEvent(t: Int, p: android.os.Bundle?) {}
    }

    private fun buildNotif(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE)
        val stopPi = PendingIntent.getService(this, 1,
            Intent(this, VoiceListenerService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, VoiceAssistantApp.CH_VOICE)
            .setContentTitle("Sesli Asistan").setContentText(text)
            .setSmallIcon(R.drawable.ic_notification).setContentIntent(pi)
            .addAction(R.drawable.ic_notification, "Durdur", stopPi)
            .setOngoing(true).setPriority(NotificationCompat.PRIORITY_LOW).build()
    }

    private fun updateNotif(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotif(text))
    }

    override fun onDestroy() {
        super.onDestroy(); isRunning = false; isListening = false
        scope.cancel(); recognizer?.destroy(); recognizer = null
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
