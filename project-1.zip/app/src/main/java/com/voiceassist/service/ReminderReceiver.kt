package com.voiceassist.service

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.voiceassist.R
import com.voiceassist.VoiceAssistantApp
import com.voiceassist.data.AppDatabase
import com.voiceassist.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReminderReceiver : BroadcastReceiver() {
    companion object {
        const val EXTRA_TEXT = "reminder_text"
        const val EXTRA_ID = "reminder_id"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val text = intent.getStringExtra(EXTRA_TEXT) ?: "Hatırlatma"
        val id = intent.getLongExtra(EXTRA_ID, 0)

        val pendingIntent = PendingIntent.getActivity(
            context, id.toInt(),
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notif = NotificationCompat.Builder(context, VoiceAssistantApp.CH_REMINDER)
            .setContentTitle("⏰ Hatırlatma")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        NotificationManagerCompat.from(context).notify(id.toInt(), notif)

        CoroutineScope(Dispatchers.IO).launch {
            AppDatabase.getInstance(context).reminderDao().markDone(id)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        // Önyükleme sonrası bekleyen hatırlatmaları yeniden zamanla
        CoroutineScope(Dispatchers.IO).launch {
            val reminders = AppDatabase.getInstance(context).reminderDao().getActive()
            reminders.forEach { ReminderManager.schedule(context, it.id, it.text, it.triggerTime) }
        }
    }
}
