package com.voiceassist.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.voiceassist.data.AppDatabase
import com.voiceassist.data.WhatsAppMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * WhatsApp bildirimlerini yakalayan servis.
 *
 * ÖNEMLİ SINIRLAMA: Bu servis SADECE servis aktifken gelen YENİ mesaj
 * bildirimlerini yakalayabilir. WhatsApp'ın geçmiş mesaj veritabanına
 * erişim YOKTUR (uçtan uca şifreleme + uygulama sandbox'ı nedeniyle).
 * Yani "geçmiş mesajları oku" değil, "yeni gelen mesajları yakala ve
 * istendiğinde sesli oku" işlevi görür.
 *
 * Kullanıcı bu servise Ayarlar > Bildirim Erişimi'nden manuel izin vermelidir.
 */
class WhatsAppListenerService : NotificationListenerService() {

    private val scope = CoroutineScope(Dispatchers.IO)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return

        // Grup özet bildirimlerini ve boş içerikleri atla
        if (title.isBlank() || text.isBlank()) return
        if (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        scope.launch {
            val db = AppDatabase.getInstance(applicationContext)
            db.whatsAppDao().insert(WhatsAppMessage(sender = title, text = text))
            // 7 günden eski mesajları temizle
            db.whatsAppDao().deleteOlderThan(System.currentTimeMillis() - 7L*24*60*60*1000)
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        // Servis bağlandı - izin verilmiş demektir
    }
}
